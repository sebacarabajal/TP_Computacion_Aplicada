#!/bin/bash

set -o nounset
set -o pipefail

show_help() {
    cat <<'EOF'
Uso:
  backup_full.sh ORIGEN DESTINO
  backup_full.sh -help

Crea un backup completo comprimido del directorio ORIGEN dentro del
directorio DESTINO. El archivo se nombra con el formato:

  nombre_bkp_YYYYMMDD.tar.gz

Ejemplos:
  backup_full.sh /var/log /backup_dir
  backup_full.sh /www_dir /backup_dir
EOF
}

case "${1:-}" in
    -help|--help|-h)
        show_help
        exit 0
        ;;
esac

if [ "$#" -ne 2 ]; then
    echo "Error: se requieren los argumentos ORIGEN y DESTINO." >&2
    show_help >&2
    exit 2
fi

source_dir=${1%/}
destination_dir=${2%/}

if [ ! -d "$source_dir" ] || [ ! -r "$source_dir" ]; then
    echo "Error: el origen '$source_dir' no existe o no se puede leer." >&2
    exit 3
fi

if ! findmnt -T "$source_dir" >/dev/null 2>&1; then
    echo "Error: el sistema de archivos del origen no esta disponible." >&2
    exit 4
fi

if [ ! -d "$destination_dir" ] || [ ! -w "$destination_dir" ]; then
    echo "Error: el destino '$destination_dir' no existe o no permite escritura." >&2
    exit 5
fi

if ! mountpoint -q "$destination_dir"; then
    echo "Error: '$destination_dir' no es un sistema de archivos montado." >&2
    exit 6
fi

source_name=$(basename "$source_dir")
backup_date=$(date +%Y%m%d)
archive="$destination_dir/${source_name}_bkp_${backup_date}.tar.gz"
temporary_archive="${archive}.tmp.$$"

cleanup() {
    rm -f -- "$temporary_archive"
}
trap cleanup EXIT HUP INT TERM

if ! tar --one-file-system -C "$(dirname "$source_dir")" -czf "$temporary_archive" "$source_name"; then
    echo "Error: no se pudo crear el backup de '$source_dir'." >&2
    exit 7
fi

mv -f -- "$temporary_archive" "$archive"
trap - EXIT HUP INT TERM

echo "Backup creado correctamente: $archive"

